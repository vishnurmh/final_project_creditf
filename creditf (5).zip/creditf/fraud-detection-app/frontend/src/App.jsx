import React, { useState } from 'react'
import axios from 'axios'
import { motion } from 'framer-motion'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'
import { CreditCard, AlertTriangle, CheckCircle, Activity, TrendingUp, Clock, DollarSign, Menu, X, Home, BarChart3, Info, Code2 } from 'lucide-react'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState('basic')
  const [formData, setFormData] = useState({
    Time: 0,
    V1: 0, V2: 0, V3: 0, V4: 0, V5: 0, V6: 0, V7: 0, V8: 0, V9: 0, V10: 0,
    V11: 0, V12: 0, V13: 0, V14: 0, V15: 0, V16: 0, V17: 0, V18: 0, V19: 0, V20: 0,
    V21: 0, V22: 0, V23: 0, V24: 0, V25: 0, V26: 0, V27: 0, V28: 0,
    Amount: 0
  })

  const [prediction, setPrediction] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [predictionTime, setPredictionTime] = useState(null)

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }))
  }

  const handlePredict = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setPrediction(null)

    const startTime = Date.now()

    try {
      const response = await axios.post(`${API_URL}/predict`, formData)
      setPrediction(response.data)
      setPredictionTime((Date.now() - startTime) / 1000)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to get prediction. Make sure the backend is running.')
    } finally {
      setLoading(false)
    }
  }

  const fillSampleData = () => {
    setFormData({
      Time: 3600,
      V1: -1.3598, V2: -0.0727, V3: 2.5363, V4: 1.3782, V5: -0.3383,
      V6: 0.4624, V7: 0.2396, V8: 0.0987, V9: 0.3638, V10: 0.0908,
      V11: -0.5516, V12: -0.6178, V13: -0.9914, V14: -0.3112, V15: 1.4682,
      V16: -0.4704, V17: 0.2080, V18: 0.0258, V19: 0.4040, V20: 0.2514,
      V21: -0.0183, V22: 0.2778, V23: -0.1105, V24: 0.0669, V25: 0.1285,
      V26: -0.1891, V27: 0.1336, V28: -0.0213,
      Amount: 149.62
    })
  }

  const chartData = prediction ? [
    { name: 'Legitimate', value: (1 - prediction.confidence) * 100, fill: '#10b981' },
    { name: 'Fraudulent', value: prediction.confidence * 100, fill: '#ef4444' }
  ] : []

  const menuItems = [
    { icon: Home, label: 'Dashboard', id: 'dashboard' },
    { icon: BarChart3, label: 'Analysis', id: 'analysis' },
    { icon: Info, label: 'Model Info', id: 'info' },
    { icon: Code2, label: 'About', id: 'about' }
  ]

  return (
    <div className="flex h-screen bg-dark-900">
      {/* Sidebar */}
      <motion.div
        initial={{ x: -280 }}
        animate={{ x: sidebarOpen ? 0 : -280 }}
        transition={{ duration: 0.3 }}
        className="w-72 glass border-r border-slate-700 p-6 fixed h-full overflow-y-auto z-50 lg:relative lg:translate-x-0"
      >
        <div className="flex items-center gap-3 mb-8">
          <CreditCard className="w-8 h-8 text-primary-500" />
          <div>
            <h1 className="font-bold text-lg text-white">FraudDetect</h1>
            <p className="text-xs text-slate-400">AI Risk Analysis</p>
          </div>
        </div>

        <nav className="space-y-2">
          {menuItems.map((item) => (
            <motion.button
              key={item.id}
              whileHover={{ x: 5 }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-slate-300 hover:bg-primary-600 hover:bg-opacity-20 hover:text-primary-400 transition-all"
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </motion.button>
          ))}
        </nav>

        <div className="mt-12 pt-6 border-t border-slate-700">
          <p className="text-xs text-slate-500 mb-3">Technology Stack</p>
          <div className="space-y-1 text-xs text-slate-400">
            <p>⚛️ React + Vite</p>
            <p>🚀 FastAPI Backend</p>
            <p>🤖 XGBoost Model</p>
            <p>📊 Real-time Analysis</p>
          </div>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="sticky top-0 z-40 glass border-b border-slate-700 px-6 py-4 lg:flex items-center justify-between hidden">
          <div>
            <h2 className="text-2xl font-bold text-white">Fraud Detection Dashboard</h2>
            <p className="text-slate-400 text-sm">Real-time ML-powered risk analysis</p>
          </div>
          <div className="text-slate-400 text-sm">
            Last Updated: {new Date().toLocaleTimeString()}
          </div>
        </div>

        {/* Mobile Header */}
        <div className="lg:hidden glass border-b border-slate-700 px-4 py-4 flex items-center justify-between">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-slate-700 rounded-lg"
          >
            {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
          <h2 className="text-xl font-bold">FraudDetect</h2>
          <div className="w-6" />
        </div>

        {/* Main Content Area */}
        <div className="p-6 max-w-7xl mx-auto">
          {/* Hero Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="glass rounded-2xl p-8 bg-gradient-to-br from-primary-600 to-primary-800 border-primary-500 border-opacity-50">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-4xl font-bold text-white mb-2">Credit Card Fraud Detection</h1>
                  <p className="text-primary-100 text-lg">Advanced machine learning powered transaction risk assessment</p>
                </div>
                <CreditCard className="w-16 h-16 text-primary-200 opacity-50" />
              </div>
            </div>
          </motion.div>

          {/* KPI Cards */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
          >
            <KPICard
              icon={AlertTriangle}
              label="Fraud Probability"
              value={prediction ? `${(prediction.confidence * 100).toFixed(1)}%` : '--'}
              color="text-red-400"
              bgColor="bg-red-900 bg-opacity-20"
            />
            <KPICard
              icon={Activity}
              label="Risk Level"
              value={prediction ? (prediction.confidence > 0.7 ? 'HIGH' : prediction.confidence > 0.3 ? 'MEDIUM' : 'LOW') : '--'}
              color={prediction ? (prediction.confidence > 0.7 ? 'text-red-400' : prediction.confidence > 0.3 ? 'text-amber-400' : 'text-emerald-400') : 'text-slate-400'}
              bgColor={prediction ? (prediction.confidence > 0.7 ? 'bg-red-900 bg-opacity-20' : prediction.confidence > 0.3 ? 'bg-amber-900 bg-opacity-20' : 'bg-emerald-900 bg-opacity-20') : 'bg-slate-800 bg-opacity-20'}
            />
            <KPICard
              icon={TrendingUp}
              label="Model Confidence"
              value={prediction ? `${(Math.max(prediction.confidence, 1 - prediction.confidence) * 100).toFixed(1)}%` : '--'}
              color="text-primary-400"
              bgColor="bg-primary-900 bg-opacity-20"
            />
          </motion.div>

          {/* Transaction Summary */}
          {(prediction || formData.Amount > 0) && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass rounded-xl p-6 mb-8"
            >
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary-400" />
                Transaction Summary
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <SummaryItem label="Amount" value={`$${formData.Amount.toFixed(2)}`} />
                <SummaryItem label="Time (sec)" value={formData.Time.toLocaleString()} />
                <SummaryItem label="Features Entered" value="30" />
                <SummaryItem label="Prediction Time" value={predictionTime ? `${(predictionTime * 1000).toFixed(0)}ms` : '--'} />
              </div>
            </motion.div>
          )}

          {/* Form and Results Container */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Input Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-2 glass rounded-xl p-8"
            >
              <h3 className="text-xl font-bold text-white mb-6">Transaction Features</h3>
              
              <form onSubmit={handlePredict}>
                {/* Tabs */}
                <div className="flex gap-2 mb-6 border-b border-slate-700 pb-4">
                  {['basic', 'v1_v10', 'v11_v20', 'v21_v28'].map((tab) => (
                    <motion.button
                      key={tab}
                      type="button"
                      onClick={() => setActiveTab(tab)}
                      whileHover={{ scale: 1.05 }}
                      className={`px-4 py-2 rounded-lg font-medium transition-all ${
                        activeTab === tab
                          ? 'bg-primary-600 text-white shadow-glow'
                          : 'text-slate-400 hover:text-slate-300'
                      }`}
                    >
                      {tab === 'basic' && 'Basic Info'}
                      {tab === 'v1_v10' && 'V1-V10'}
                      {tab === 'v11_v20' && 'V11-V20'}
                      {tab === 'v21_v28' && 'V21-V28'}
                    </motion.button>
                  ))}
                </div>

                {/* Tab Content */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {activeTab === 'basic' && (
                    <>
                      <InputField name="Time" label="Time (seconds)" value={formData.Time} onChange={handleInputChange} />
                      <InputField name="Amount" label="Amount ($)" value={formData.Amount} onChange={handleInputChange} step="0.01" />
                    </>
                  )}
                  {activeTab === 'v1_v10' && ['V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10'].map(v => (
                    <InputField key={v} name={v} label={v} value={formData[v]} onChange={handleInputChange} step="0.01" />
                  ))}
                  {activeTab === 'v11_v20' && ['V11', 'V12', 'V13', 'V14', 'V15', 'V16', 'V17', 'V18', 'V19', 'V20'].map(v => (
                    <InputField key={v} name={v} label={v} value={formData[v]} onChange={handleInputChange} step="0.01" />
                  ))}
                  {activeTab === 'v21_v28' && ['V21', 'V22', 'V23', 'V24', 'V25', 'V26', 'V27', 'V28'].map(v => (
                    <InputField key={v} name={v} label={v} value={formData[v]} onChange={handleInputChange} step="0.01" />
                  ))}
                </div>

                {/* Buttons */}
                <div className="flex gap-4">
                  <motion.button
                    type="submit"
                    disabled={loading}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex-1 bg-gradient-to-r from-primary-600 to-primary-500 text-white font-bold py-3 px-6 rounded-lg hover:shadow-glow disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Activity className="w-5 h-5" />
                        Analyze Transaction
                      </>
                    )}
                  </motion.button>
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.02 }}
                    onClick={fillSampleData}
                    className="px-6 py-3 rounded-lg border border-primary-500 text-primary-400 hover:bg-primary-600 hover:bg-opacity-10 font-medium"
                  >
                    Load Sample
                  </motion.button>
                </div>
              </form>
            </motion.div>

            {/* Results Section */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              {error && (
                <div className="glass rounded-xl p-6 bg-red-900 bg-opacity-20 border border-red-500 border-opacity-50">
                  <div className="flex items-start gap-4">
                    <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-red-400 mb-1">Error</h3>
                      <p className="text-red-300 text-sm">{error}</p>
                    </div>
                  </div>
                </div>
              )}

              {prediction && (
                <motion.div
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className={`glass rounded-xl p-6 border ${
                    prediction.prediction === 1
                      ? 'border-red-500 border-opacity-50 bg-gradient-fraud'
                      : 'border-emerald-500 border-opacity-50 bg-gradient-legitimate'
                  }`}
                >
                  <div className="flex items-start gap-4 mb-6">
                    {prediction.prediction === 1 ? (
                      <AlertTriangle className="w-8 h-8 text-red-400 flex-shrink-0" />
                    ) : (
                      <CheckCircle className="w-8 h-8 text-emerald-400 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <h3 className={`text-2xl font-bold mb-2 ${
                        prediction.prediction === 1 ? 'text-red-400' : 'text-emerald-400'
                      }`}>
                        {prediction.prediction === 1 ? '🚨 FRAUD ALERT' : '✅ LEGITIMATE'}
                      </h3>
                      <p className="text-slate-300">{prediction.message}</p>
                    </div>
                  </div>

                  {/* Confidence Bar */}
                  <div className="mb-6">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-slate-400">Fraud Probability</span>
                      <span className="text-sm font-bold text-white">{(prediction.confidence * 100).toFixed(2)}%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${prediction.confidence * 100}%` }}
                        transition={{ duration: 0.8, ease: 'easeOut' }}
                        className={`h-full rounded-full ${
                          prediction.prediction === 1
                            ? 'bg-gradient-to-r from-red-600 to-red-400'
                            : 'bg-gradient-to-r from-emerald-600 to-emerald-400'
                        }`}
                      />
                    </div>
                  </div>

                  {/* Chart */}
                  {chartData.length > 0 && (
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie
                          data={chartData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value.toFixed(1)}%`} />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </motion.div>
              )}

              {!prediction && !error && (
                <div className="glass rounded-xl p-8 text-center border-2 border-dashed border-slate-700">
                  <CreditCard className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400">Fill in the transaction details and click "Analyze Transaction" to get started</p>
                </div>
              )}
            </motion.div>
          </div>
        </div>

        {/* Footer */}
        <div className="glass border-t border-slate-700 mt-12">
          <div className="max-w-7xl mx-auto px-6 py-8 text-center text-slate-400 text-sm">
            <p>Built with React + Vite | FastAPI Backend | XGBoost ML Model | Powered by Advanced AI</p>
          </div>
        </div>
      </div>
    </div>
  )
}

// Helper Components
function KPICard({ icon: Icon, label, value, color, bgColor }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      className={`glass rounded-xl p-6 ${bgColor}`}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-slate-400 text-sm mb-1">{label}</p>
          <p className={`text-3xl font-bold ${color}`}>{value}</p>
        </div>
        <Icon className={`w-12 h-12 ${color} opacity-50`} />
      </div>
    </motion.div>
  )
}

function SummaryItem({ label, value }) {
  return (
    <div>
      <p className="text-slate-400 text-xs mb-1">{label}</p>
      <p className="text-white font-semibold">{value}</p>
    </div>
  )
}

function InputField({ name, label, value, onChange, step = 'any' }) {
  return (
    <motion.div whileHover={{ scale: 1.02 }}>
      <label className="block text-sm text-slate-300 mb-2 font-medium">
        {label}
      </label>
      <input
        type="number"
        name={name}
        value={value}
        onChange={onChange}
        step={step}
        className="w-full bg-dark-800 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:ring-opacity-20"
      />
    </motion.div>
  )
}

export default App

