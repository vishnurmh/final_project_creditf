# 💳 Credit Card Fraud Detection Web Application

A full-stack web application for real-time credit card fraud detection using machine learning. Built with **React + Vite** (frontend) and **FastAPI** (backend), powered by XGBoost.

## 📋 Project Structure

```
fraud-detection-app/
├── frontend/                 # React + Vite application
│   ├── src/
│   │   ├── App.jsx          # Main React component
│   │   ├── App.css          # Styling
│   │   └── main.jsx         # Entry point
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── .env                 # Backend API URL
│
└── backend/                  # FastAPI application
    ├── main.py              # FastAPI routes & ML logic
    ├── requirements.txt     # Python dependencies
    └── .env                 # Configuration
```

## 🚀 Quick Start

### Prerequisites
- **Node.js** 18+ (for frontend)
- **Python** 3.8+ (for backend)
- **xgboost_fraud_model.pkl** and **scaler.pkl** (model files)

### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create a virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # macOS/Linux
   source venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Place your model files in the backend directory:
   - `xgboost_fraud_model.pkl`
   - `scaler.pkl`

5. Run the backend server:
   ```bash
   uvicorn main:app --reload
   ```

   The API will be available at `http://localhost:8000`

### Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

   The app will open at `http://localhost:5173`

## 📊 API Endpoints

### Health Check
```bash
GET /health
```
Returns the API status and model loading status.

### Make a Prediction
```bash
POST /predict
Content-Type: application/json

{
  "Time": 3600,
  "V1": -1.36, "V2": -0.07, ..., "V28": -0.02,
  "Amount": 149.62
}
```

**Response:**
```json
{
  "prediction": 0,
  "confidence": 0.95,
  "message": "✓ Legitimate transaction (Confidence: 95.00%)"
}
```

### Batch Prediction
```bash
POST /batch-predict
Content-Type: application/json

[
  { "Time": 3600, "V1": -1.36, ..., "Amount": 149.62 },
  { "Time": 3700, "V1": -1.40, ..., "Amount": 200.00 }
]
```

## 🎨 Frontend Features

- **Modern Dashboard**: Clean, responsive UI with dark theme
- **Input Sections**: Organized into Transaction Details and Feature Groups (V1-V28)
- **Load Sample Data**: Quickly test with pre-filled legitimate transaction
- **Real-time Predictions**: Instant feedback from the backend
- **Confidence Visualization**: Visual indicator of fraud probability
- **Loading States**: User feedback during API calls
- **Error Handling**: Clear error messages for failed requests

## 🔧 Configuration

### Frontend (.env)
```
VITE_API_URL=http://localhost:8000
```

### Backend (.env)
```
CORS_ORIGINS=http://localhost:5173,http://localhost:3000
```

## 📦 Dependencies

### Frontend
- `react@18.2.0` - UI library
- `react-dom@18.2.0` - React DOM renderer
- `axios@1.6.0` - HTTP client
- `vite@5.0.0` - Build tool

### Backend
- `fastapi@0.104.1` - Web framework
- `uvicorn[standard]@0.24.0` - ASGI server
- `xgboost@2.0.3` - ML model format
- `scikit-learn@1.3.2` - Model preprocessing
- `numpy@1.24.3` - Numerical computing
- `joblib@1.3.2` - Model persistence
- `pydantic@2.5.0` - Data validation

## 🛠️ Production Deployment

### Frontend
```bash
npm run build
```
Builds the optimized production bundle in the `dist/` directory.

### Backend
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

For production, consider using a production ASGI server like Gunicorn or use Docker.

## 📝 Example Usage

1. **Open the dashboard** at `http://localhost:5173`
2. **Click "Load Sample Data"** to fill in a test transaction
3. **Click "Predict Fraud"** to get the fraud detection result
4. **View the result** with confidence score and message

## 🔒 Security Notes

- Change `allow_origins=["*"]` in `main.py` for production
- Keep your API key and model files secure
- Use HTTPS in production
- Implement rate limiting for the API

## 📊 Model Information

The application uses an XGBoost classifier trained on credit card transaction features:
- **30 Features**: Time, V1-V28 (PCA-transformed), Amount
- **Output**: Binary classification (0 = Legitimate, 1 = Fraud)
- **Confidence**: Probability of fraudulent transaction

## 🐛 Troubleshooting

### Backend won't start
- Ensure Python 3.8+ is installed
- Check that all dependencies are installed: `pip install -r requirements.txt`
- Verify `xgboost_fraud_model.pkl` and `scaler.pkl` exist in the backend directory

### Frontend connection issues
- Check that the backend is running on `http://localhost:8000`
- Verify VITE_API_URL in `.env` matches the backend URL
- Check browser console for CORS errors

### No predictions
- Ensure model files are in the backend directory
- Check server logs for model loading errors
- Verify all 30 features are provided (required for XGBoost)

## 📞 Support

For issues or questions, check:
1. Server logs and console output
2. Browser console for client-side errors
3. Network tab in browser DevTools

## 📄 License

This project is provided as-is for educational purposes.
