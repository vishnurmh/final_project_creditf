from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import joblib
import numpy as np
from pydantic import BaseModel
from typing import List
import os

# Initialize FastAPI app
app = FastAPI(title="Credit Card Fraud Detection API", version="1.0.0")

# Enable CORS for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins (modify for production)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model and scaler
try:
    model = joblib.load("xgboost_fraud_model.pkl")
    scaler = joblib.load("scaler.pkl")
    print("✓ Model and scaler loaded successfully")
except FileNotFoundError as e:
    print(f"⚠ Warning: {e}")
    model = None
    scaler = None


class PredictionRequest(BaseModel):
    """Request model for fraud prediction."""
    Time: float
    V1: float
    V2: float
    V3: float
    V4: float
    V5: float
    V6: float
    V7: float
    V8: float
    V9: float
    V10: float
    V11: float
    V12: float
    V13: float
    V14: float
    V15: float
    V16: float
    V17: float
    V18: float
    V19: float
    V20: float
    V21: float
    V22: float
    V23: float
    V24: float
    V25: float
    V26: float
    V27: float
    V28: float
    Amount: float


class PredictionResponse(BaseModel):
    """Response model for fraud prediction."""
    prediction: int  # 0 = legitimate, 1 = fraud
    confidence: float  # Probability of fraud
    message: str


@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "message": "Credit Card Fraud Detection API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "model_loaded": model is not None,
        "scaler_loaded": scaler is not None
    }


@app.post("/predict", response_model=PredictionResponse)
async def predict(request: PredictionRequest):
    """
    Predict whether a transaction is fraudulent.
    
    Accepts all 30 numerical features (Time, V1-V28, Amount).
    Returns prediction (0 or 1) and confidence score.
    """
    if model is None or scaler is None:
        return {
            "prediction": -1,
            "confidence": 0.0,
            "message": "Model not loaded"
        }
    
    try:
        # Prepare features in correct order
        features = np.array([[
            request.Time,
            request.V1, request.V2, request.V3, request.V4, request.V5,
            request.V6, request.V7, request.V8, request.V9, request.V10,
            request.V11, request.V12, request.V13, request.V14, request.V15,
            request.V16, request.V17, request.V18, request.V19, request.V20,
            request.V21, request.V22, request.V23, request.V24, request.V25,
            request.V26, request.V27, request.V28,
            request.Amount
        ]])
        
        # Scale features
        scaled_features = scaler.transform(features)
        
        # Get prediction and probability
        prediction = int(model.predict(scaled_features)[0])
        probability = float(model.predict_proba(scaled_features)[0][1])
        
        # Generate message
        if prediction == 1:
            message = f"⚠ FRAUD DETECTED (Confidence: {probability:.2%})"
        else:
            message = f"✓ Legitimate transaction (Confidence: {1-probability:.2%})"
        
        return {
            "prediction": prediction,
            "confidence": probability,
            "message": message
        }
    
    except Exception as e:
        return {
            "prediction": -1,
            "confidence": 0.0,
            "message": f"Prediction error: {str(e)}"
        }


@app.post("/batch-predict")
async def batch_predict(requests: List[PredictionRequest]):
    """
    Predict multiple transactions at once.
    """
    if model is None or scaler is None:
        return {
            "error": "Model not loaded",
            "predictions": []
        }
    
    try:
        # Prepare all features
        all_features = []
        for req in requests:
            features = [
                req.Time,
                req.V1, req.V2, req.V3, req.V4, req.V5,
                req.V6, req.V7, req.V8, req.V9, req.V10,
                req.V11, req.V12, req.V13, req.V14, req.V15,
                req.V16, req.V17, req.V18, req.V19, req.V20,
                req.V21, req.V22, req.V23, req.V24, req.V25,
                req.V26, req.V27, req.V28,
                req.Amount
            ]
            all_features.append(features)
        
        all_features = np.array(all_features)
        scaled_features = scaler.transform(all_features)
        
        # Get predictions
        predictions = model.predict(scaled_features)
        probabilities = model.predict_proba(scaled_features)[:, 1]
        
        results = []
        for pred, conf in zip(predictions, probabilities):
            results.append({
                "prediction": int(pred),
                "confidence": float(conf),
                "message": "Fraud detected" if pred == 1 else "Legitimate"
            })
        
        return {
            "count": len(results),
            "predictions": results
        }
    
    except Exception as e:
        return {
            "error": str(e),
            "predictions": []
        }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
